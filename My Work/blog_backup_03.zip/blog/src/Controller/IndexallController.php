<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Articles Controller
 *
 * @property \App\Model\Table\ArticlesTable $Articles
 * @method \App\Model\Entity\Article[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
/**
 * Categories Controller
 *
 * @property \App\Model\Table\CategoriesTable $Categories
 * @method \App\Model\Entity\Category[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */

 /**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class IndexallController extends AppController
{
    
    
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function display()
    {
        
    $this->loadmodel('Users');
    $queryActive = $this->Users->find('all')->where(['Users.loggedin_users'=>1])->count();
    $this->set('logU', $queryActive);

    $this->loadmodel('Users');
    $queryU  = $this->Users->find('all')->where(['Users.active_users'=>1])->count();
    $this->set('total_reportU', $queryU);

    $this->loadmodel('Articles');
    $queryA  = $this->Articles->find('all')->count();
    $this->set('total_reportA', $queryA);

    $this->loadmodel('Categories');
    $queryC  = $this->Categories->find('all')->count();
    $this->set('total_reportC', $queryC);
        
        return $this->render('indexall');
    }
   
}
