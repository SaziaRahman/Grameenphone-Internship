<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Category> $categories
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <ul><li><?= $this->Html->link("Home Page", array('controller' => 'Indexall', 'action' => 'display')) ?></li>
                <li><?= $this->Html->link("List Articles", array('controller' => 'articles', 'action' => 'index')) ?></li>
            
<li><?= $this->Html->link("List Categories", array('controller' => 'categories', 'action' => 'index')) ?></li>
<li><?= $this->Html->link("List Users", array('controller' => 'users', 'action' => 'index')) ?></li></ul>
        </div>
    </aside>
    <div class="column-responsive column-80">
        
<div class="actions large-2 medium-3 columns">
    <h2><?= __('Categories') ?></h2>
    <ul class="side-nav">
        <li><?= $this->Html->link(__('New Category'), ['action' => 'add'], ['class' => 'side-nav-item']) ?></li>
    </ul>
</div>
<div class="categories index large-10 medium-9 columns">
    <table cellpadding="0" cellspacing="0">
    <thead>
        <tr>
            <th>Id</th>
            <th>Parent Id</th>
            <th>Lft</th>
            <th>Rght</th>
            <th>Name</th>
            <th>Description</th>
            <th>Created</th>
            <th>Created By</th>
        <th>Modified By</th>
            <th class="actions"><?= __('Actions') ?></th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($categories as $category): ?>
        
        <tr>
            <td><?= $category->id ?></td>
            <td><?= $category->parent_id ?></td>
            <td><?= $category->lft ?></td>
            <td><?= $category->rght ?></td>
            <td><?= h($category->name) ?></td>
            <td><?= h($category->description) ?></td>
            <td><?= h($category->created) ?></td>
            <td>
            <?= $category->created_by ?>
        </td>
        <td>
            <?= $category->modified_by ?>
        </td>
            <td class="actions">
                <?= $this->Html->link(__('<i class="fas fa-eye"></i>'), ['action' => 'view', $category->id],['escape'=>false]) ?>
                <?= $this->Html->link(__('<i class="fas fa-edit"></i>'), ['action' => 'edit', $category->id], ['escape'=>false]) ?>
                <?= $this->Form->postLink(__('<i class="fas fa-trash"></i>'), ['action' => 'delete', $category->id], ['escape'=>false], ['confirm' => __('Are you sure you want to delete # {0}?', $category->id)]) ?>
                <?= $this->Form->postLink(__('<i class="fas fa-arrow-down"></i>'), ['action' => 'moveDown', $category->id], ['escape'=>false], ['confirm' => __('Are you sure you want to move down # {0}?', $category->id)]) ?>
                <?= $this->Form->postLink(__('<i class="fas fa-arrow-up"></i>'), ['action' => 'moveUp', $category->id], ['escape'=>false], ['confirm' => __('Are you sure you want to move up # {0}?', $category->id)]) ?>
            </td>
        </tr>
        
    <?php endforeach; ?>
    </tbody>
    </table>
    <?= $this->Paginator->counter() ?>

<ul class="pagination"><?php echo $this->Paginator->prev('« Previous')."<<".$this->Paginator->numbers().">>".$this->Paginator->next('Next »') ?></ul>
    
</div>

