<!-- File: templates/Articles/add.php -->
<?php

/**
 * Categories Controller
 *
 * @property \App\Model\Table\ArticlesTable $Articles
 * @method \App\Model\Entity\Article[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Article $article
 * @var \Cake\Collection\CollectionInterface|string[] $category_id
 */
/**
 * 
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <ul><li><?= $this->Html->link("Home Page", array('controller' => 'articles', 'action' => 'index')) ?></li>
            
<li><?= $this->Html->link("List Categories", array('controller' => 'categories', 'action' => 'index')) ?></li>
<li><?= $this->Html->link("List Users", array('controller' => 'users', 'action' => 'index')) ?></li></ul>
        </div>
    </aside>
    <div class="column-responsive column-80">
<h1>Add Article</h1>

<?php
echo $this->Form->create($article);
// just added the categories control
echo $this->Form->control('category_id', ['options'=> $categories]);
echo $this->Form->control('title');
echo $this->Form->control('body', ['rows' => '3']);
echo $this->Form->button(__('Save Article'));
echo $this->Form->end();
?>