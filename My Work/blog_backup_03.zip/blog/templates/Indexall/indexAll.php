<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <ul><li><?= $this->Html->link("Home Page", array('controller' => 'Indexall', 'action' => 'display')) ?></li>
                <li><?= $this->Html->link("List Articles", array('controller' => 'articles', 'action' => 'index')) ?></li>
           
<li><?= $this->Html->link("List Categories", array('controller' => 'categories', 'action' => 'index')) ?></li>
<li><?= $this->Html->link("List Users", array('controller' => 'users', 'action' => 'index')) ?></li></ul>
        </div>
    </aside>
    <div class="column-responsive column-80">
    
    <div class="indexall index content">
    <h1>Blog</h1>
    <div class="column">
    <aside class="row">
    <div class="indexall01 index content" style="background-color:#fe4d25; width: 25%">
    <h3>Logged In Users</h3>
    <h4>
        <?php echo $logU?>
</h4>
    </div>
    <div class="indexall02 index content" style="background-color:#febdef; width: 25%">
    <h3>Active Users</h3>
    <h4>
        <?php echo $total_reportU?>
</h4>
    </div>
    <div class="indexall03 index content" style="background-color:#ffbd1b; width: 25%">
    <h3>Articles</h3>
    <h4>
        <?php echo $total_reportA?>
</h4>
    </div>
    <div class="indexall04 index content" style="background-color:#ffbdbf; width: 25%">
    <h3>Categories</h3>
    <h4>
        <?php echo $total_reportC?>
</h4>
    </div>
</aside>
    <div class="column-responsive column-250">
    </div>
  
