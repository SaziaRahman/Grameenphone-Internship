<h1>Edit User</h1>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Users'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">

<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\User $user
 */
echo $this->Form->create($user);
    echo $this->Form->control('email');
    echo $this->Form->control('role', ['options' => ['admin' => 'Admin', 'author' => 'Author']]);
    echo $this->Form->control('active_users',['options' =>['InActive','Active']]);
    echo $this->Form->control('created');
    echo $this->Form->control('modified');
    echo $this->Form->control('password');
    echo $this->Form->button(__('Save User'));
    echo $this->Form->end();
?>



       