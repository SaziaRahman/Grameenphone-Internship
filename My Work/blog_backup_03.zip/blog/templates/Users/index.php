<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\User> $users
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <ul><li><?= $this->Html->link("Home Page", array('controller' => 'Indexall', 'action' => 'display')) ?></li>
                <li><?= $this->Html->link("List Articles", array('controller' => 'articles', 'action' => 'index')) ?></li>
           
<li><?= $this->Html->link("List Categories", array('controller' => 'categories', 'action' => 'index')) ?></li>
<li><?= $this->Html->link("List Users", array('controller' => 'users', 'action' => 'index')) ?></li></ul>
        </div>
    </aside>
    <div class="column-responsive column-80">
<div class="users index content">
    <?= $this->Html->link(__('New User'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Users') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('email') ?></th>
                    <th><?= $this->Paginator->sort('role') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= $this->Number->format($user->id) ?></td>
                    <td><?= h($user->email) ?></td>
                    <td><?= h($user->role) ?></td>
                    <td><?= h($user->created) ?></td>
                    <td><?= h($user->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('<i class="fas fa-eye"></i>'), ['action' => 'view', $user->id],['escape'=>false]) ?>
                        <?= $this->Html->link(__('<i class="fas fa-edit"></i>'), ['action' => 'edit', $user->id], ['escape'=>false]) ?>
                        <?= $this->Form->postLink(__('<i class="fas fa-trash"></i>'), ['action' => 'delete', $user->id], ['escape'=>false], ['confirm' => __('Are you sure you want to delete # {0}?', $user->id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?= $this->Paginator->counter() ?>

<ul class="pagination"><?php echo $this->Paginator->prev('« Previous')."<<".$this->Paginator->numbers().">>".$this->Paginator->next('Next »') ?></ul>
    </div>
  
