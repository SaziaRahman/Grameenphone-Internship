<?php

?>

 
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <ul><li><?= $this->Html->link("Home Page", array('controller' => 'articles', 'action' => 'index')) ?></li>
           
<li><?= $this->Html->link("List Categories", array('controller' => 'categories', 'action' => 'index')) ?></li>
<li><?= $this->Html->link("List Users", array('controller' => 'users', 'action' => 'index')) ?></li></ul>
        </div>
    </aside>
    <div class="column-responsive column-80">
    <h1>Blog articles</h1>
    <div class="actions large-2 medium-3 columns">
    <h3></h3>
    <ul class="side-nav">
    <li><?= $this->Html->link(__('Add Article'), array('controller' => 'articles','action' => 'add')) ?>
</li>
    </ul>
</div>
<div class="categories index large-10 medium-9 columns">
<?= $this->Form->create(null,['type'=> 'get']);  ?>
    <?php echo " <div class='row'><div class='col-sm'>".$this->Form->control('s_category',['label'=>'Search by category','options'=>$categories,'empty'=> 'Choose one option', 'value'=>$this->request->getQuery('s_category')])."</div><div class='col-sm'>"
    .$this->Form->control('s_title',['label'=>'Search by title', 'value'=>$this->request->getQuery('s_title')])."</div><div class='col-sm'>"
    .$this->Form->control('s_date',['label'=>'Search by date', 'value'=>$this->request->getQuery('s_date'),'type'=>'date'])."</div></div>"
    .$this->Form->submit('Search', ['action'=>'index']);  ?>
    <?= $this->Form->end();  ?>  
    
    
<table>
    <tr>
        <th>Category</th>
        <th>Id</th>
        <th>Title</th>
        <th>Created</th>
        <th>Created By</th>
        <th>Modified By</th>
         <th>Actions</th>
    </tr>

<!-- Here's where we loop through our $articles query object, printing out article info -->

    <?php foreach ($articles as $article): ?>
    <tr>
    <td>
                <?= $article->has('category') ? $article->category->name : '' ?>
            </td>
        <td><?= $article->id ?></td>
        <td>
            <?= $this->Html->link($article->title, ['action' => 'view', $article->id]) ?>
        </td>
        <td>
            <?= $article->created ?>
        </td>
        <td>
        <?= $article->has('user') ? $article->user->email : '' ?>
        </td>
        <td>
        <?= $article->modified_by ?>
        </td>
        <td>
           
        <?= $this->Form->postLink(
                '<i class="fas fa-trash"></i>',
                ['action' => 'delete', $article->id],
                ['escape'=>false],
                ['confirm' => 'Are you sure?'])
            ?>
           <?= $this->Html->link('<i class="fas fa-edit"></i>', ['action' => 'edit', $article->id],['escape'=>false]) ?>
        </td>
    </tr>
    <?php endforeach; ?>

</table>
<?= $this->Paginator->counter() ?>

<ul class="pagination"><?php echo $this->Paginator->prev('« Previous')."<<".$this->Paginator->numbers().">>".$this->Paginator->next('Next »') ?></ul>


<?php if($this->Identity->isLoggedIn()):?>
<?php endif;?>



