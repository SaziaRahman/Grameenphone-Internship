<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\User $user
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <ul><li><?= $this->Html->link("Home Page", array('controller' => 'articles', 'action' => 'index')) ?></li>
            
<li><?= $this->Html->link("List Categories", array('controller' => 'categories', 'action' => 'index')) ?></li>
<li><?= $this->Html->link("List Users", array('controller' => 'users', 'action' => 'index')) ?></li></ul>
        </div>
    </aside>
    <div class="column-responsive column-80">


        <div class="users form">
            <?= $this->Form->create($user) ?>

            <fieldset>
                <legend><?= __('Add User') ?></legend>
                <?= $this->Form->control('email') ?>
                <?= $this->Form->control('created') ?>
                <?= $this->Form->control('modified') ?>
                <?= $this->Form->control('password') ?>
                <?= $this->Form->control('role', [
                    'options' => ['admin' => 'Admin', 'author' => 'Author']
                    //$options["author"]


                ]) ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')); ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>