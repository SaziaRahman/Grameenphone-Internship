<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Articles Controller
 *
 * @property \App\Model\Table\ArticlesTable $Articles
 * @method \App\Model\Entity\Article[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
/**
 * Categories Controller
 *
 * @property \App\Model\Table\CategoriesTable $Categories
 * @method \App\Model\Entity\Category[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */

 /**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ArticlesController extends AppController
{
    
    
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $s_title=$this->request->getQuery('s_title');
        $s_category=$this->request->getQuery('s_category');
        $s_date=$this->request->getQuery('s_date');

        $query  = $this->Articles->find('all')->contain(['Categories','Users']);

        if(isset($s_title) || isset($s_category) || isset($s_date))
        {
            $query->where(['title like'=>'%'.$s_title.'%'])->where('articles.category_id LIKE("%'.$s_category.'%")')->where('articles.created LIKE("%'.$s_date.'%")');
        }
      

    
        
        $articles = $this->paginate($query,['limit' => 3,
        'order' => [
            'Articles.title' => 'asc'
        ]]);
        //$articles = $this->paginate($this->Articles);
        //$this->set(compact('articles'));
        $categories = $this->Articles->Categories->find('list',['limit'=> 200])->all();
        $this->set(compact('articles','categories'));
        
        
        $this->set('_serialize', ['articles']);
    }

    /**
     * View method
     *
     * @param string|null $id Article id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $article = $this->Articles->get($id, [
            'contain' => ['Categories','Users'],
        ]);

        $this->set(compact('article'));
    }

    

   
    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        
    // Do delete operation
    $this->loadmodel('Users');
    //$roles = $this->Users->find()->all()->extract('role');
    
    
  //  $this->set('groups', $this->Users->find()->select('id')->where(['id'=> $rol]));
  
  $rol=$this->Authentication->getIdentity()->get('id');
  //$groups=$this->Users->find()->select('email')->where(['id'=> $rol]);
  

        $article = $this->Articles->newEmptyEntity();
        if ($this->request->is('post')) {

            $article->created_by=$rol;

            $article = $this->Articles->patchEntity($article, $this->request->getData());
            if ($this->Articles->save($article)) {
                $this->Flash->success(__('Your article has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Unable to add your article.'));
        }
        $this->set('article', $article);

        // Just added the categories list to be able to choose
        // one category for an article
        $categories = $this->Articles->Categories->find('list',['limit'=> 200])->all();
        $this->set(compact('article','categories'));
     
    }
    

    /**
     * Edit method
     *
     * @param string|null $id Article id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $this->loadmodel('Users');
    //$roles = $this->Users->find()->all()->extract('role');
    
    $rol1=$this->Authentication->getIdentity()->get('id');
  $groups=$this->Users->find()->select('email')->where(['id'=> $rol1]);
    
    
        $article = $this->Articles->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $article->modified_by=$groups;
            $article = $this->Articles->patchEntity($article, $this->request->getData());
            if ($this->Articles->save($article)) {
                $this->Flash->success(__('The article has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The article could not be saved. Please, try again.'));
        }
        $categories = $this->Articles->Categories->find('list', ['limit' => 200])->all();
        $this->set(compact('article', 'categories'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Article id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $article = $this->Articles->get($id);
        if ($this->Articles->delete($article)) {
            $this->Flash->success(__('The article has been deleted.'));
        } else {
            $this->Flash->error(__('The article could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
